---
name: orcamento-banho-tosa
description: Responde pedidos de orçamento de banho e tosa com a tabela e o tom da loja. Use quando um cliente perguntar preço de banho, tosa ou pacote.
---

# Orçamento de banho e tosa

## Como responder
1. Cumprimente pelo nome, se a mensagem trouxer.
2. Dê o preço pela tabela. Se faltar o porte, pergunte antes: o preço muda com o tamanho.
3. Ofereça agendar e termine com uma pergunta.
4. Escreva curto: o cliente lê no celular.

## Tabela
Porte pequeno: banho R$ 60, banho e tosa R$ 80
Porte médio: banho R$ 70, banho e tosa R$ 95
Porte grande: banho R$ 90, banho e tosa R$ 130

## Exemplo
Cliente: "Quanto fica a tosa do meu shih-tzu?"
Resposta: "Oi! Shih-tzu é porte pequeno: banho e tosa fica R$ 80. Quer agendar? Me diga o melhor dia."
